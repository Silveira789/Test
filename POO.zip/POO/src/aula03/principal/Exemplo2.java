package aula03.principal;

public class Exemplo2 {

     int atributoC;


}
