package aula03.modelo;

import aula02.principal.Principal;

public class Exemplo extends Principal {

    public int atributoA;

    private int atributoB;
    protected int atributoD;




}
